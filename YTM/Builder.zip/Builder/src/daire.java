public class daire implements IsekilCreator {
    private sekil sekil = new sekil("daire");

    public daire() {
        this.sekil = new sekil("Daire");
    }

    @Override
    public void turuOlustur() {
        sekil.setTuru("Daire");
    }

    @Override
    public void kenarSayisiOlustur() {
        sekil.setKenarsayisi(0);
    }

    @Override
    public void baslangicNoktasiOlustur() {
        sekil.setBaslangicNoktasi(0);
    }

    @Override
    public void kenarUzunluguOlustur() {
        sekil.setKenarUzunlugu(0);
    }

    @Override

    public void kenarKalinligiOlustur() {
        sekil.setKenarKalinligi(0);
    }

    @Override
    public void kenarRengiOlustur() {
        sekil.setKenarRengi("Siyah");
    }

    @Override
    public void dolguRengiOlustur() {
        sekil.setDolguRengi("Siyah");
    }

    @Override
    public sekil getSekil() {
        return sekil;
    }

}
