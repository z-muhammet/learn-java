public class App {
    public static void main(String[] args) {
        daire daire = new daire();
        sekilMenager sekilMenager = new sekilMenager(daire);
        sekilMenager.sekilOlustur();
        sekil daire1 = sekilMenager.getSekil();
        System.out.println(daire1);
        kare kare = new kare();
        sekilMenager sekilMenager1 = new sekilMenager(kare);
        sekilMenager1.sekilOlustur();
        sekil kare1 = sekilMenager1.getSekil();
        System.out.println(kare1);
        
    }
}