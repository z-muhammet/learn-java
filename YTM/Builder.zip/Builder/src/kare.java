public class kare implements IsekilCreator {
    sekil sekil = new sekil("kare");

    public kare() {
        this.sekil = new sekil("Kare");
    }

    @Override
    public void turuOlustur() {
        sekil.setTuru("Kare");
    }

    @Override
    public void kenarSayisiOlustur() {
        sekil.setKenarsayisi(4);
    }

    @Override
    public void baslangicNoktasiOlustur() {
        sekil.setBaslangicNoktasi(0);
    }

    @Override
    public void kenarUzunluguOlustur() {
        sekil.setKenarUzunlugu(0);
    }

    @Override
    public void kenarKalinligiOlustur() {
        sekil.setKenarKalinligi(0);
    }

    @Override
    public void kenarRengiOlustur() {
        sekil.setKenarRengi("Siyah");
    }

    @Override
    public void dolguRengiOlustur() {
        sekil.setDolguRengi("Siyah");
    }

    @Override
    public sekil getSekil() {
        return sekil;
    }

    
}
