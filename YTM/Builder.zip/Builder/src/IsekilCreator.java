public interface IsekilCreator {
    void turuOlustur();

    void kenarSayisiOlustur();

    void baslangicNoktasiOlustur();

    void kenarUzunluguOlustur();

    void kenarKalinligiOlustur();

    void kenarRengiOlustur();

    void dolguRengiOlustur();

    sekil getSekil();
}
